package softuni.exam.domain.entities;

public class Team {
    //TODO
}
