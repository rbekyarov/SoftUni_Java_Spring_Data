package softuni.exam.service;

public interface PictureService {
    String importPictures();

    boolean areImported();

    String readPicturesXmlFile();
}
