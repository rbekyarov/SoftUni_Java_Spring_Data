package softuni.exam.domain.entities;

public class Player {
    //TODO
}
