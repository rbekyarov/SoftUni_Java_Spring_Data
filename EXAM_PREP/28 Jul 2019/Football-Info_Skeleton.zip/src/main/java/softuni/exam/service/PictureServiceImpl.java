package softuni.exam.service;

import org.springframework.stereotype.Service;

@Service
public class PictureServiceImpl implements PictureService {
    @Override
    public String importPictures() {
        //TODO Implement me
        return "";
    }

    @Override
    public boolean areImported() {
        //TODO Implement me
        return false;
    }

    @Override
    public String readPicturesXmlFile() {
        //TODO Implement me
        return "";
    }

}
