package softuni.exam.domain.entities;

public class Picture {
    //TODO
}
