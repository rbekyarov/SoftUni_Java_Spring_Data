package softuni.exam.service;

import org.springframework.stereotype.Service;

@Service
public class TeamServiceImpl implements TeamService {

    @Override
    public String importTeams() {
        //TODO Implement me
        return "";
    }

    @Override
    public boolean areImported() {
        //TODO Implement me
        return false;
    }

    @Override
    public String readTeamsXmlFile(){
        //TODO Implement me
        return "";
    }
}
