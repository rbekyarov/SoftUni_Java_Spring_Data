package softuni.exam.service;

public interface TeamService {

    String importTeams();

    boolean areImported();

    String readTeamsXmlFile();
}
