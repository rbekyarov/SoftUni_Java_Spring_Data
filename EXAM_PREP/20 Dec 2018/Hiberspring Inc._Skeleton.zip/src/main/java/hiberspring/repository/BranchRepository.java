package hiberspring.repository;

public interface BranchRepository {
    // TODO: Implement me
}
