package hiberspring.repository;

public interface EmployeeRepository {
    // TODO: Implement me
}
