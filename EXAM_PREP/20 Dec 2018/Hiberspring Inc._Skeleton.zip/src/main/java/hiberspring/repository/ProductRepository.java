package hiberspring.repository;

public interface ProductRepository {
    // TODO: Implement me
}
