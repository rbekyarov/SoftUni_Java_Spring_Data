package hiberspring.repository;

public interface TownRepository {
    // TODO: Implement me
}
