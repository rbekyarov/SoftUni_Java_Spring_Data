package hiberspring.repository;

public interface EmployeeCardRepository {
    // TODO: Implement me
}
