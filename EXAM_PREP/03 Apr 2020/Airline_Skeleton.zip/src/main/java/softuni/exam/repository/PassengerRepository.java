package softuni.exam.repository;





public interface PassengerRepository  {
    
}
