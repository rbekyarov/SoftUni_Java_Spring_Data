package softuni.exam.repository;



public interface TownRepository  {

}
