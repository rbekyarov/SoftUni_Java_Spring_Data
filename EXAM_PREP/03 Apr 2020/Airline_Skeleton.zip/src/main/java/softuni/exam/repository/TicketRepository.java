package softuni.exam.repository;



public interface TicketRepository  {

}
