package softuni.exam.repository;



public interface PlaneRepository  {

}
