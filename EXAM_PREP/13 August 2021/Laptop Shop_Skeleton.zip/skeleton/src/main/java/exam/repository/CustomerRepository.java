package exam.repository;

//ToDo:
public interface CustomerRepository {
}
